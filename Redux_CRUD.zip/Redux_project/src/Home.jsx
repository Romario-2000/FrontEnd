import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { deleteUser } from "./userReducer";

const Home = () => {
    const userData = useSelector((state) => state.users)
    const dispatch = useDispatch()

    const handleDelete = (id) => {
        dispatch(deleteUser({
            id:id
        }))
    }

    return (
        <>
            <div className="container">
                <h2>CRUD App</h2>
                <Link to='/create' className='btn btn-success my-3' > Create</Link>
                <table className="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {userData.map((i, index) => (
                            <tr key={index}>
                                <td>{i.id}</td>
                                <td>{i.name}</td>
                                <td>{i.email}</td>
                                <td>
                                    <Link to={`/edit/${i.id}`} className="btn btn-sm btn-primary">Edit</Link>
                                    <button onClick={() => handleDelete(i.id)} className="btn btn-sm btn-danger ms-2">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </>
    )
}

export default Home;