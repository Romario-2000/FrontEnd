export const userData = [
    {
        id:1,
        name:'mario',
        email:'mario@gmail.com',
    },
    {
        id:2,
        name:'raju',
        email:'raju@gmail.com',
    }
]