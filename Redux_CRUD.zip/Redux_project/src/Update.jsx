import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { updateUser } from "./userReducer";

const Update = () => {
    const { userId } = useParams();
    const users = useSelector((state) => state.users)

    const existingUser = users.find((i) => i.id === Number(userId))
    if (!existingUser) {
        return <h3>User not found</h3>;
    }
    const { name, email } = existingUser

    const [updateName, setUpdateName] = useState(name);
    const [updateEmail, setUpdateEmail] = useState(email);

    const dispatch = useDispatch();

    const navigate = useNavigate();

    const handleUpdate = (event) => {
        event.preventDefault();
        dispatch(updateUser({
            id: userId,
            name: updateName,
            email: updateEmail
        }))
        navigate('/')
    }

    return (
        <div className="d-flex w-100 justify-content-center align-items-center">
            <div className="w-50 border bg-secondary text-white p-5">
                <h3>Update user</h3>
                <form onSubmit={handleUpdate}>
                    <div>
                        <label htmlFor="name">Name:</label>
                        <input type="text" name="name" className="form-control" value={updateName} onChange={(e) => setUpdateName(e.target.value)} />
                    </div>
                    <div>
                        <label htmlFor="email">Email:</label>
                        <input type="text" name="email" className="form-control" value={updateEmail} onChange={(e) => setUpdateEmail(e.target.value)} />
                    </div>
                    <button className="btn btn-info mt-2">Submit</button>
                </form>
            </div>
        </div>
    )
}

export default Update;