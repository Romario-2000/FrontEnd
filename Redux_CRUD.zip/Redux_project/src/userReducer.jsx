import { createSlice } from "@reduxjs/toolkit";
import { userData } from "./Data";

const userSlice = createSlice({
    name: "users",
    initialState: userData,
    reducers: {
        adduser: (state, action) => {
            state.push(action.payload)
        },
        updateUser: (state, action) => {
            const { id, name, email } = action.payload;
            const updateUser = state.find((i) => i.id == id)

            if(updateUser){
                updateUser.name = name;
                updateUser.email = email;
            }
        },
        deleteUser: (state,action) =>{
            const {id} = action.payload;
            const deleteUser = state.find((i)=>i.id == id)
            if(deleteUser){
                return state.filter((i)=> i.id !== id);
            }
        }
    }
})

export const { adduser, updateUser,deleteUser } = userSlice.actions
export default userSlice.reducer;

