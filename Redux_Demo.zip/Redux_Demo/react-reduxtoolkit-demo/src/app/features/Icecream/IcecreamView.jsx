import { useSelector,useDispatch } from "react-redux";
import { ordered, restocked } from "./icecreamSlice";
import { useState } from "react";

const IcecreamView = () => {
  const dispatch = useDispatch()
  const [val,setVal]=useState(1)
 

  const numOfIcecreams = useSelector((state) => 
    state.icecream.numOfIcecreams
  );
  return (
    <div>
      <h2>No of icecream - {numOfIcecreams} </h2>
      <button onClick={()=>dispatch(ordered())}>Order icecream</button>
      <input type="number" value={val} onChange={(e)=>setVal(parseInt(e.target.value))}/>
      <button onClick={()=>dispatch(restocked(val))}>Restock icecream</button>
    </div>
  );
};

export default IcecreamView;
