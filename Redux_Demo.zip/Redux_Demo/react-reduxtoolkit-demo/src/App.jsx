import './App.css'
import CakeView from './app/features/Cake/CakeView'
import IcecreamView from './app/features/Icecream/IcecreamView'
import UserView from './app/features/user/userView'
function App() {

  return (
    <>
      <CakeView/>
      <IcecreamView/>
      <UserView/>
    </>
  )
}

export default App
